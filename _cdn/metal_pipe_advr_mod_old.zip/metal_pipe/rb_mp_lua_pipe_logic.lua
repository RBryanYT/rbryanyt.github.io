function onLoad()
	base.LoadAssetBundle("mods/metal_pipe/rb_mp_assets_pipe_sfx")
	sound = base.GetObjectFromAssetBundle("pain", "UnityEngine.AudioClip")
	audio.CreateNewSoundEffect("metal_pipe", {sound}, 1, true, 100)
end

function onPlayerHit(damage)
	audio.playSoundLocal("metal_pipe", player.transform.position)
	return damage
end

function onPrimaryHitEntity(infos)
	if infos.entity ~= nil then
		audio.playSoundLocal("metal_pipe", player.transform.position)
	end
	return infos.damage
end

function onSecondaryHitEntity(infos)
	if infos.entity ~= nil then
		audio.playSoundLocal("metal_pipe", player.transform.position)
	end
	return infos.damage
end

function onEntityDeath(living, source)
	if source == player.LocalPlayerRef then
		audio.playSoundLocal("metal_pipe", player.transform.position)
	end
end

function onFoodEaten(food)
	audio.playSoundLocal("metal_pipe", player.transform.position)
end

function onPickupTaken(takenPickup, gameObject)
	audio.playSoundLocal("metal_pipe", player.transform.position)
end

function onKnifeCollide(knife, collision)
	audio.playSoundLocal("metal_pipe", player.transform.position)
end

-- audio.playSoundLocal("metal_pipe", player.transform.position)